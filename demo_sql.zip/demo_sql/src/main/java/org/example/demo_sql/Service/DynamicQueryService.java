package org.example.demo_sql.Service;


import org.example.demo_sql.Config.SqlWhiteList;
import org.example.demo_sql.DTO.QueryRequest;
import org.example.demo_sql.Mapper.DynamicQueryMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.logging.Logger;

@Service
public class DynamicQueryService {

    @Autowired
    private DynamicQueryMapper queryMapper;

    @Autowired
    private SqlWhiteList sqlWhiteList;

    private static final Logger logger = Logger.getLogger(DynamicQueryService.class.getName());

    public List<Map<String, Object>> dynamicQuery(QueryRequest req) {
        // 1. 校验表名


        if (!sqlWhiteList.isTableAllowed(req.getTable())) {
            throw new IllegalArgumentException("非法表名: " + req.getTable());
        }

        logger.info("开始查询数据，表名: " + req.getTable());

        // 2. 处理字段
        List<String> safeFields = new ArrayList<>();
        if (req.getFields() == null || req.getFields().isEmpty()) {
            safeFields.add("*");  // 如果前端没传，就默认查全部
        } else {
            for (String field : req.getFields()) {
                if (!sqlWhiteList.isFieldAllowed(req.getTable(), field)) {
                    throw new IllegalArgumentException("非法字段: " + field);
                }
                safeFields.add(field);
            }
        }
        logger.info("开始查询数据， " + safeFields );

        // 拼接 SELECT 子句
        StringBuilder sql = new StringBuilder("SELECT ")
                .append(String.join(",", safeFields))
                .append(" FROM ").append(req.getTable());

        // 3. 条件
        Map<String, Object> params = new HashMap<>();
        if (req.getConditions() != null && !req.getConditions().isEmpty()) {
            sql.append(" WHERE 1=1 ");
            req.getConditions().forEach((k, v) -> {
                if (!sqlWhiteList.isFieldAllowed(req.getTable(), k)) {
                    throw new IllegalArgumentException("非法条件字段: " + k);
                }

                // 解析条件
                if (v instanceof Map) {
                    // 提取 operator 和 value
                    Map<String, Object> conditionMap = (Map<String, Object>) v;
                    String operator = (String) conditionMap.get("operator");
                    Object value = conditionMap.get("value");

                    // 判断 operator 是否有效
                    if (operator != null && value != null) {
                        switch (operator) {
                            case "=":
                                sql.append(" AND ").append(k).append(" = #{params.").append(k).append("}");
                                break;
                            case ">":
                                sql.append(" AND ").append(k).append(" > #{params.").append(k).append("}");
                                break;
                            case "<":
                                sql.append(" AND ").append(k).append(" < #{params.").append(k).append("}");
                                break;
                            case ">=":
                                sql.append(" AND ").append(k).append(" >= #{params.").append(k).append("}");
                                break;
                            case "<=":
                                sql.append(" AND ").append(k).append(" <= #{params.").append(k).append("}");
                                break;
                            case "LIKE":
                                sql.append(" AND ").append(k).append(" LIKE #{params.").append(k).append("}");
                                break;
                            case "IN":
                                sql.append(" AND ").append(k).append(" IN (#{params.").append(k).append("})");
                                break;
                            case "BETWEEN":
                                Map<String, Object> range = (Map<String, Object>) value;
                                sql.append(" AND ").append(k).append(" BETWEEN #{params.").append(k).append(".min} AND #{params.").append(k).append(".max}");
                                params.put(k, range);  // 如果是范围查询，确保传入的范围数据正确
                                break;
                            default:
                                throw new IllegalArgumentException("Unsupported operator: " + operator);
                        }
                        params.put(k, value);  // 将条件值添加到 params 中
                    }
                }
            });
        }

        // 打印生成的 SQL 查询和参数
        System.out.println("Generated SQL: " + sql);
        System.out.println("Parameters: " + params);

        logger.info("生成的 SQL 查询: " + sql);
        logger.info("生成的 SQL 参数: " + params);

        // 4. 排序
        if (req.getOrderBy() != null && !req.getOrderBy().isEmpty()) {
            sql.append(" ORDER BY ").append(req.getOrderBy());
        }

        // 5. 分组和聚合
        if (req.getGroupBy() != null && !req.getGroupBy().isEmpty()) {
            sql.append(" GROUP BY ").append(req.getGroupBy());
        }

        // 6. Having 条件：只有当 groupBy 存在时才加上 HAVING 条件
        if (req.getHaving() != null && !req.getHaving().isEmpty()) {
            sql.append(" HAVING ").append(req.getHaving());
        }

        // 7. 限制数量
        if (req.getLimit() == null) {
            sql.append(" LIMIT 100");  // 默认返回 100 条数据
        } else {
            sql.append(" LIMIT ").append(req.getLimit());
        }

        // 8. 自定义 SQL 片段
        if (req.getCustomSql() != null && !req.getCustomSql().isEmpty()) {
            sql.append(" ").append(req.getCustomSql());
        }

        // 9. JOIN 连接：只有在 join 不为空时才拼接
        if (req.getJoin() != null && !req.getJoin().isEmpty()) {
            sql.append(" ").append(req.getJoin());
        }

        // 执行查询
        return queryMapper.dynamicQuery(sql.toString(), params);
    }

    public List<Map<String, Object>> executeQuery(String table, List<String> fields, Map<String, Object> conditions,
                                                  Integer limit, String orderBy, String groupBy, String having,
                                                  String customSql, String join) {
        QueryRequest req = new QueryRequest();
        req.setTable(table);
        req.setFields(fields);
        req.setConditions(conditions);
        req.setLimit(limit);
        req.setOrderBy(orderBy);
        req.setGroupBy(groupBy);
        req.setHaving(having);
        req.setCustomSql(customSql);
        req.setJoin(join);

        return dynamicQuery(req);
    }
}

