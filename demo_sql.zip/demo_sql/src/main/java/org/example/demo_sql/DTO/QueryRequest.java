package org.example.demo_sql.DTO;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class QueryRequest {
    private String table;
    private List<String> fields;
    private Map<String, Object> conditions;
    private Integer limit;
    private String orderBy;
    private String groupBy;
    private String having;
    private String customSql;
    private String join;
}
