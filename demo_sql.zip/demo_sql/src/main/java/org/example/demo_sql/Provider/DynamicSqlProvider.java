package org.example.demo_sql.Provider;

import java.util.Map;

public class DynamicSqlProvider {
    public String buildSql(String sql, Map<String, Object> params) {
        // 根据params可以对sql进行动态构建
        return sql;
    }
}