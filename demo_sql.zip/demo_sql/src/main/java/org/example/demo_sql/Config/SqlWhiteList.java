package org.example.demo_sql.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
public class SqlWhiteList {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // 允许查询的表
    private static final Set<String> ALLOWED_TABLES = new HashSet<>(Arrays.asList("dim_customer", "dim_product"));
    // 每张表允许的字段
    private static final Map<String, Set<String>> ALLOWED_FIELDS = new HashMap<>();

    @PostConstruct
    public void init() {
        for (String table : ALLOWED_TABLES) {
            // 查询 INFORMATION_SCHEMA.COLUMNS 获取每个表的列信息
            String sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ?";
            List<String> columns = jdbcTemplate.queryForList(sql, String.class, table);

            // 存储查询到的字段
            Set<String> fields = new HashSet<>(columns);
            ALLOWED_FIELDS.put(table, fields);
        }

        // 确保查询完成后打印所有表和字段信息
        printAllowedTablesAndFields();
    }

    private void printAllowedTablesAndFields() {
        System.out.println("白名单初始化完成: ");
        ALLOWED_TABLES.forEach(table -> {
            System.out.println("表名: " + table);
            Set<String> fields = ALLOWED_FIELDS.get(table);
            if (fields != null) {
                System.out.println("  可用字段: " + String.join(", ", fields));
            }
        });
    }

    // 校验表名是否合法
    public boolean isTableAllowed(String table) {
        return ALLOWED_TABLES.contains(table);
    }

    // 校验字段是否合法（此处不做字段限制，返回true）
    public boolean isFieldAllowed(String table, String field) {
        return true;  // 不限制字段
    }
}