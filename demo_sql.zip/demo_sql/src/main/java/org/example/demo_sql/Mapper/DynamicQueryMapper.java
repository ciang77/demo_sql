package org.example.demo_sql.Mapper;



import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;
import org.example.demo_sql.Provider.DynamicSqlProvider;

import java.util.List;
import java.util.Map;

@Mapper
public interface DynamicQueryMapper {
    @SelectProvider(type = DynamicSqlProvider.class, method = "buildSql")
    List<Map<String, Object>> dynamicQuery(@Param("sql") String sql, @Param("params") Map<String, Object> params);
}



