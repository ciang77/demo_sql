package org.example.demo_sql.Controller;


import org.example.demo_sql.DTO.QueryRequest;
import org.example.demo_sql.Service.DynamicQueryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/query")
public class QueryController {

    private final DynamicQueryService queryService;

    // 构造方法注入
    public QueryController(DynamicQueryService queryService) {
        this.queryService = queryService;
    }

    @PostMapping("/execute")
    public ResponseEntity<?> executeQuery(@RequestBody QueryRequest request) {
        try {
            // 调用 service 执行 SQL
            List<Map<String, Object>> result = queryService.executeQuery(
                    request.getTable(),
                    request.getFields(),
                    request.getConditions(),
                    request.getLimit() != null ? request.getLimit() : 50,   // 默认限制50条
                    request.getOrderBy() != null ? request.getOrderBy() : "", // 默认不排序
                    request.getGroupBy(),  // 分组可以为空
                    request.getHaving(),   // Having 条件可以为空
                    request.getCustomSql(), // 自定义 SQL 片段可以为空
                    request.getJoin()
            );

            return ResponseEntity.ok(result);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("请求参数不合法: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("执行查询失败: " + e.getMessage());
        }
    }
}
