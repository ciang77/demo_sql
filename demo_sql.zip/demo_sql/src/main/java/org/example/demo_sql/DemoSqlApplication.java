package org.example.demo_sql;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("org.example.demo_sql.Mapper")
@SpringBootApplication
public class DemoSqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSqlApplication.class, args);
    }

}
